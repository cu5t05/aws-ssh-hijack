// index.js
// Plug-and-play Cognito Post-Authentication → DynamoDB "last login" writer.
// Assumes: env var TABLE_NAME is set to your DynamoDB table name.

const { DynamoDBClient, PutItemCommand } = require("@aws-sdk/client-dynamodb");

// Let Lambda/SDK auto-pick region/credentials from environment.
const ddb = new DynamoDBClient({});

exports.handler = async (event) => {
  // Minimal, safe logging
  console.log("Trigger:", event.triggerSource || "unknown");

  // Prefer the stable Cognito user UUID
  const userSub =
    event?.request?.userAttributes?.sub ||
    event?.userName || // fallback
    null;

  const tableName = process.env.TABLE_NAME;
  const timestamp = new Date().toISOString();

  // Quick guards for plug-and-play safety
  if (!tableName) {
    console.error("Missing env TABLE_NAME");
    return event; // don't block auth flow
  }
  if (!userSub) {
    console.error("Missing user sub in event");
    return event; // don't block auth flow
  }

  try {
    await ddb.send(
      new PutItemCommand({
        TableName: tableName,
        Item: {
          user_sub: { S: userSub },
          last_login_timestamp: { S: timestamp },
        },
      })
    );
    console.log(`Last login upserted: ${userSub} @ ${timestamp}`);
  } catch (err) {
    // Log and allow auth to proceed (PostAuth should not be fatal)
    console.error("DynamoDB PutItem failed:", err);
  }

  // Cognito requires returning the (possibly modified) event
  return event;
};
